#include "CognitiveVREditorPrivatePCH.h"
#include "SceneSetupWindow.h"

/*void USceneSetupWindow::ExportScene()
{
	//SelectExportMeshes();

	FEditorFileUtils::Export(true);

	//ExportDirectory = FEditorDirectories::Get().GetLastDirectory(ELastDirectory::UNR);

	//RunBlenderCleanup();
}*/