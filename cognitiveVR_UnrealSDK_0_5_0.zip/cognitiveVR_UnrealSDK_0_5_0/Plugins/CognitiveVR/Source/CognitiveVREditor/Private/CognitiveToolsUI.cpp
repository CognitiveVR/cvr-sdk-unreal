
#include "CognitiveVREditorPrivatePCH.h"
#include "CognitiveTools.h"

#define LOCTEXT_NAMESPACE "BaseToolEditor"

static TArray<TSharedPtr<FDynamicData>> SceneDynamics;
static TArray<TSharedPtr<FDynamicData>> SceneExplorerDynamics;
static TArray<TSharedPtr<FString>> SubDirectoryNames;

//deals with all the interface stuff in the editor preferences
//includes any details needed to make the ui work

void FCognitiveTools::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	TSet<UClass*> Classes;

	TArray<TWeakObjectPtr<UObject>> ObjectsBeingCustomized;
	DetailBuilder.GetObjectsBeingCustomized(ObjectsBeingCustomized);

	DetailLayoutPtr = &DetailBuilder;

	UClass* Class = NULL;

	for (auto WeakObject : ObjectsBeingCustomized)
	{
		if (UObject* instance = WeakObject.Get())
		{
			Class = instance->GetClass();
			break;
		}
	}


	IDetailCategoryBuilder& SettingsCategory = DetailBuilder.EditCategory(TEXT("Export Settings"));

	MinPolygonProperty = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UCognitiveVRSettings, MinPolygons));
	MaxPolygonProperty = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UCognitiveVRSettings, MaxPolygons));
	StaticOnlyProperty = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UCognitiveVRSettings, staticOnly));
	MinSizeProperty = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UCognitiveVRSettings, MinimumSize));
	MaxSizeProperty = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UCognitiveVRSettings, MaximumSize));
	TextureResizeProperty = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UCognitiveVRSettings, TextureResizeFactor));
	ExcludeMeshProperty = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(UCognitiveVRSettings, ExcludeMeshes));

	// Create a commands category
	IDetailCategoryBuilder& LoginCategory = DetailBuilder.EditCategory(TEXT("Account"),FText::GetEmpty(),ECategoryPriority::Important);

	//simple spacer
	/*LoginCategory.AddCustomRow(FText::FromString("Commands"))
	.ValueContent()
	.HAlign(HAlign_Fill)
	[
		SNew(SHorizontalBox)
		.Visibility(EVisibility::Hidden)
	];*/
	

	
	LoginCategory.AddCustomRow(FText::FromString("Commands"))
	.ValueContent()
	.HAlign(HAlign_Fill)
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.MaxWidth(96)
		[
			SNew(STextBlock)
			.Text(FText::FromString("Developer Key"))
		]

		+ SHorizontalBox::Slot()
		.MaxWidth(128)
		[
			SNew(SEditableTextBox)
			.MinDesiredWidth(128)
			.Text(this, &FCognitiveTools::GetDeveloperKey)
			.OnTextChanged(this,&FCognitiveTools::OnDeveloperKeyChanged)
		]
	];

	LoginCategory.AddCustomRow(FText::FromString("Commands"))
	.ValueContent()
	.HAlign(HAlign_Fill)
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.MaxWidth(96)
		[
			SNew(STextBlock)
			.Text(FText::FromString("API Key"))
		]

		+ SHorizontalBox::Slot()
		.MaxWidth(128)
		[
			SNew(SEditableTextBox)
			.MinDesiredWidth(128)
			.Text(this, &FCognitiveTools::GetAPIKey)
			.OnTextChanged(this,&FCognitiveTools::OnAPIKeyChanged)
		]
	];

	LoginCategory.AddCustomRow(FText::FromString("Commands"))
	.ValueContent()
	.MinDesiredWidth(256)
	[
		SNew(SButton)
		.Text(FText::FromString("Save"))
		//.IsEnabled(this,&FCognitiveTools::HasSelectedValidProduct)
		.OnClicked(this, &FCognitiveTools::SaveAPIDeveloperKeysToFile)
	];

	LoginCategory.AddCustomRow(FText::FromString("Commands"))
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.HAlign(EHorizontalAlignment::HAlign_Center)
		[
			SNew(STextBlock)
			.Visibility(this, &FCognitiveTools::ConfigFileChangedVisibility)
			.ColorAndOpacity(FLinearColor::Yellow)
			.Text(FText::FromString("Config files changed. Data displayed below may be incorrect until you restart Unreal Editor!"))
		]
	];

	IDetailCategoryBuilder& ExportedSceneData = DetailBuilder.EditCategory(TEXT("Exported Scene Data"));

	ExportedSceneData.AddCustomRow(FText::FromString("Commands"))
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.HAlign(EHorizontalAlignment::HAlign_Center)
		[
			SNew(SButton)
			.HAlign(EHorizontalAlignment::HAlign_Center)
			.IsEnabled(this, &FCognitiveTools::HasDeveloperKey)
			.Text(FText::FromString("Get Latest Scene Version Data"))
			.ToolTip(SNew(SToolTip).Text(LOCTEXT("get scene data tip", "This will get the latest scene version data from Scene Explorer and saves it to your config files. Must restart Unreal Editor to see the changes in your config files here")))
			.OnClicked(this, &FCognitiveTools::DebugRefreshCurrentScene)
		]
	];

	ExportedSceneData.AddCustomRow(FText::FromString("Commands"))
	[
			SNew(SBox)
			.MaxDesiredHeight(200)
			[
			SNew(SListView<TSharedPtr<FEditorSceneData>>)
			.ItemHeight(24)
			.ListItemsSource(&SceneData)
			.OnGenerateRow(this, &FCognitiveTools::OnGenerateWorkspaceRow)
			.HeaderRow(
				SNew(SHeaderRow)
				+ SHeaderRow::Column("name")
				.FillWidth(1)
				[
					SNew(STextBlock)
					//.MinDesiredWidth(256)
					.Text(FText::FromString("Name"))
				]

				+ SHeaderRow::Column("id")
				.FillWidth(1)
				[
					SNew(STextBlock)
					//.MinDesiredWidth(512)
					.Text(FText::FromString("Id"))
				]

				+ SHeaderRow::Column("version number")
				.FillWidth(0.3)
				[
					SNew(STextBlock)
					.Text(FText::FromString("Version Number"))
				]

				+ SHeaderRow::Column("version id")
				.FillWidth(0.3)
				[
					SNew(STextBlock)
					.Text(FText::FromString("Version Id"))
				]

				+ SHeaderRow::Column("open")
				[
					SNew(STextBlock)
					.Text(FText::FromString("Scene Explorer"))
				]
			)
		]
	];

	IDetailCategoryBuilder& SceneWorkflow = DetailBuilder.EditCategory(TEXT("Scene Upload Workflow"));
	SceneWorkflow.InitiallyCollapsed(true);

	SceneWorkflow.AddCustomRow(FText::FromString("Commands"))
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.Padding(4.0f, 0.0f)
		[
			SNew(SVerticalBox)
			+SVerticalBox::Slot()
			.Padding(0,0,0,4)
			.HAlign(EHorizontalAlignment::HAlign_Center)
			[
				SNew(STextBlock)
				.Text(FText::FromString("1. Export Settings"))
			]
			+SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SHorizontalBox)
				+SHorizontalBox::Slot()
				.AutoWidth()
				[
					SNew(SCheckBox)
					.IsEnabled(false)
					.IsChecked(this, &FCognitiveTools::HasFoundBlenderCheckbox)
				]
				+SHorizontalBox::Slot()
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasDeveloperKey)
					.Text(FText::FromString("Select Blender.exe"))
					.OnClicked(this, &FCognitiveTools::Select_Blender)
				]
			]
			+ SVerticalBox::Slot()
			[
				SNew(SProperty, ExcludeMeshProperty)
				.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
				.ShouldDisplayName(true)
			]
			+SVerticalBox::Slot()
			[
				SNew(SProperty,StaticOnlyProperty)
				.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
				.ShouldDisplayName(true)
			]
			+ SVerticalBox::Slot()
			[
				SNew(SProperty, MinSizeProperty)
				.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
				.ShouldDisplayName(true)
			]
			+ SVerticalBox::Slot()
			[
				SNew(SProperty, MaxSizeProperty)
				.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
				.ShouldDisplayName(true)
			]

			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SButton)
				.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
				.Text(FText::FromString("Select Export Meshes"))
				.OnClicked(this, &FCognitiveTools::Select_Export_Meshes)
			]
		]

		+ SHorizontalBox::Slot()
		.Padding(4.0f, 0.0f)
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()

			.HAlign(EHorizontalAlignment::HAlign_Center)
			[
				SNew(STextBlock)
				.Text(FText::FromString("2. Export"))
			]

			+ SVerticalBox::Slot()
			.Padding(0, 0, 0, 4)
			.HAlign(EHorizontalAlignment::HAlign_Center)
			[
				SNew(STextBlock)
				.ColorAndOpacity(FLinearColor::Yellow)
				.Text(FText::FromString("Important - Export as \"*.obj\"!"))
			]

			+ SVerticalBox::Slot()
			.MaxHeight(32)
			[
				SNew(SButton)
				.IsEnabled(this, &FCognitiveTools::HasFoundBlenderAndHasSelection)
				.Text(FText::FromString("Export Selected Scene Actors"))
				.OnClicked(this, &FCognitiveTools::Export_Selected)
			]
			+ SVerticalBox::Slot()
			.MaxHeight(32)
			[
				SNew(SButton)
				.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
				.Text(FText::FromString("Export All Scene Actors"))
				.OnClicked(this, &FCognitiveTools::Export_All)
			]
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f, 0.0f)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(0, 0, 0, 4)
			.HAlign(EHorizontalAlignment::HAlign_Center)
			[
				SNew(STextBlock)
				.Text(FText::FromString("3. Optimize Files"))
			]

			+SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
					.Text(FText::FromString("Select Export Directory"))
					.OnClicked(this, &FCognitiveTools::Select_Export_Directory)
				]
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(STextBlock)
				.Text(this, &FCognitiveTools::GetExportDirectory)
			]

			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasSetExportDirectory)
					.Text(FText::FromString("Export Transparent Textures"))
					.OnClicked(this, &FCognitiveTools::List_Materials)
				]
			]


			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SProperty, MinPolygonProperty)
				.IsEnabled(this, &FCognitiveTools::LoginAndCustonerIdAndBlenderExportDir)
				.ShouldDisplayName(true)
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SProperty, MaxPolygonProperty)
				.IsEnabled(this, &FCognitiveTools::LoginAndCustonerIdAndBlenderExportDir)
				.ShouldDisplayName(true)
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::LoginAndCustonerIdAndBlenderExportDir)
					.Text(FText::FromString("Reduce Mesh Topology"))
					.OnClicked(this, &FCognitiveTools::Reduce_Meshes)
				]
			]

			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SProperty, TextureResizeProperty)
				.IsEnabled(this, &FCognitiveTools::LoginAndCustonerIdAndBlenderExportDir)
				.ShouldDisplayName(true)
			]
			+ SVerticalBox::Slot()
			.AutoHeight()
			[
				SNew(SBox)
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::LoginAndCustonerIdAndBlenderExportDir)
					.Text(FText::FromString("Convert Textures"))
					.OnClicked(this, &FCognitiveTools::Reduce_Textures)
				]
			]
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f, 0.0f)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.Padding(0, 0, 0, 4)
			.HAlign(EHorizontalAlignment::HAlign_Center)
			[
				SNew(STextBlock)
				.Text(FText::FromString("4. Upload"))
			]
			+ SVerticalBox::Slot()
			.MaxHeight(32)
			[
				SNew(SButton)
				.IsEnabled(this,&FCognitiveTools::HasSetExportDirectory)
				.Text(FText::FromString("Take Screenshot"))
				.OnClicked(this, &FCognitiveTools::TakeScreenshot)
			]

			+ SVerticalBox::Slot()
			.MaxHeight(32)
			[
				SNew(SButton)
				.IsEnabled(this, &FCognitiveTools::CanUploadSceneFiles)
				.Text(this, &FCognitiveTools::UploadSceneNameFiles)
				.ToolTip(SNew(SToolTip).Text(LOCTEXT("export tip", "Make sure you have settings.json and no .bmp files in your export directory")))
				.OnClicked(this, &FCognitiveTools::UploadScene)
			]
			//+ SVerticalBox::Slot()
			//.MaxHeight(32)
			//[
			//	SNew(SButton)
			//	.IsEnabled(this, &FCognitiveTools::CurrentSceneHasSceneId)
			//	.Text(FText::FromString("Upload Screenshot"))
			//	.OnClicked(this, &FCognitiveTools::SelectUploadScreenshot)
			//]
		]
		+ SHorizontalBox::Slot()
		.Padding(4.0f, 0.0f)
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.Padding(0, 0, 0, 4)
			.HAlign(EHorizontalAlignment::HAlign_Center)
			[
				SNew(STextBlock)
				.Text(FText::FromString("5. Scene Explorer"))
			]
			+ SVerticalBox::Slot()
			.MaxHeight(32)
			[
				SNew(SButton)
				.IsEnabled(this, &FCognitiveTools::CurrentSceneHasSceneId)
				.Text(this, &FCognitiveTools::OpenSceneNameInBrowser)
				.OnClicked(this, &FCognitiveTools::OpenCurrentSceneInBrowser)
			]
		]
		
	];


	IDetailCategoryBuilder& DynamicWorkflow = DetailBuilder.EditCategory(TEXT("Dynamic Upload Workflow"));

	DynamicWorkflow.InitiallyCollapsed(true);

	DynamicWorkflow.AddCustomRow(FText::FromString("Commands"))
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.Padding(4.0f, 0.0f)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromString("1. Export"))
				]
				+ SVerticalBox::Slot()
				.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.ColorAndOpacity(FLinearColor::Yellow)
					.Text(FText::FromString("Important - Export as \"*.obj\"!"))
				]
				+ SVerticalBox::Slot()
				.MaxHeight(32)
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasFoundBlenderHasSelection)
					.Text(FText::FromString("Export Selected Dynamic Objects"))
					.OnClicked(this, &FCognitiveTools::ExportSelectedDynamics)
				]
				+ SVerticalBox::Slot()
				.MaxHeight(32)
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasFoundBlender)
					.Text(FText::FromString("Export All Dynamic Object Meshes"))
					.OnClicked(this, &FCognitiveTools::ExportDynamics)
				]
			]
			+ SHorizontalBox::Slot()
			.Padding(4.0f, 0.0f)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0, 0, 0, 4)
				.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromString("2. Organize Meshes"))
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SButton)
					.IsEnabled(this,&FCognitiveTools::HasDeveloperKey)
					.Text(FText::FromString("Select Dynamic Mesh Directory"))
					.OnClicked(this, &FCognitiveTools::SelectDynamicsDirectory)
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(STextBlock)
					.Text(this, &FCognitiveTools::GetDynamicExportDirectory)
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SButton)
					.IsEnabled(this,& FCognitiveTools::HasSetDynamicExportDirectory)
					.Text(FText::FromString("Refresh Sub Directories"))
					.OnClicked(this, &FCognitiveTools::RefreshDynamicSubDirectory)
				]
				+ SVerticalBox::Slot()
				[
					SNew(SBox)
					.HeightOverride(100)
					[
						SAssignNew(SubDirectoryListWidget,SFStringListWidget)
						.Items(GetSubDirectoryNames())
					]
				]
			]
			+ SHorizontalBox::Slot()
			.Padding(4.0f, 0.0f)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.Padding(0, 0, 0, 4)
				.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromString("3. Upload"))
				]
				+ SVerticalBox::Slot()
				.MaxHeight(32)
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasSetDynamicExportDirectoryHasSceneId)
					.Text(this, &FCognitiveTools::GetDynamicObjectUploadText)
					.OnClicked(this, &FCognitiveTools::UploadDynamics)
				]
			]
		];


	IDetailCategoryBuilder& DynamicManifestWorkflow = DetailBuilder.EditCategory(TEXT("Dynamic Objects"));

	DynamicManifestWorkflow.InitiallyCollapsed(true);

	DynamicManifestWorkflow.AddCustomRow(FText::FromString("Commands"))
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0, 0, 0, 4)
				.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromString("Dynamic Objects In Scene"))
				]
				+ SVerticalBox::Slot()
				.FillHeight(1)
				[
					SNew(SBox)
					.HeightOverride(300)
					[
						SAssignNew(SceneDynamicObjectList,SDynamicObjectListWidget)
						.CognitiveTools(this)
						.Items(SceneDynamics)
					]
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasDeveloperKey)
					.Text(FText::FromString("Refresh"))
					.OnClicked(this, &FCognitiveTools::RefreshDisplayDynamicObjectsCountInScene)
				]

				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(STextBlock)
					.Text(this,&FCognitiveTools::DisplayDynamicObjectsCountInScene)
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(STextBlock)
					.ColorAndOpacity(FLinearColor::Yellow)
					.Visibility(this,&FCognitiveTools::GetDuplicateDyanmicObjectVisibility)
					.Text(FText::FromString("Scene contains some duplicate Dynamic Object Ids"))
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SButton)
					.IsEnabled(this, &FCognitiveTools::HasDeveloperKey)
					.Text(FText::FromString("Set Unique Dynamic Ids"))
					.OnClicked(this, &FCognitiveTools::SetUniqueDynamicIds)
				]
			]
			+ SHorizontalBox::Slot()
			.Padding(4.0f, 0.0f)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(0, 0, 0, 4)
				.HAlign(EHorizontalAlignment::HAlign_Center)
				[
					SNew(STextBlock)
					.Text(FText::FromString("Dynamic Objects on SceneExplorer"))
				]
				+SVerticalBox::Slot()
				.FillHeight(1)
				[
					SNew(SBox)
					.HeightOverride(300)
					[
						SAssignNew(WebDynamicList,SDynamicObjectWebListWidget)
					]
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(STextBlock)
					.Text(this, &FCognitiveTools::DisplayDynamicObjectsCountOnWeb)
				]
				+ SVerticalBox::Slot()
				.AutoHeight()
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					[
						SNew(SButton)
						.IsEnabled(this,&FCognitiveTools::HasDeveloperKey)
						.ToolTip(SNew(SToolTip).Text(this,&FCognitiveTools::GetDynamicsOnSceneExplorerTooltip))
						.Text(FText::FromString("Get Dynamics List from SceneExplorer"))
						.OnClicked(this, &FCognitiveTools::GetDynamicsManifest)
					]
					+ SHorizontalBox::Slot()
					[
						SNew(SButton)
						.IsEnabled(this, &FCognitiveTools::HasDeveloperKey)
						.ToolTip(SNew(SToolTip).Text(this, &FCognitiveTools::SendDynamicsToSceneExplorerTooltip))
						.Text(FText::FromString("Send Dynamics List to SceneExplorer"))
						.OnClicked(this, &FCognitiveTools::UploadDynamicsManifest)
					]
				]
			]
		];


	FCognitiveTools::RefreshSceneData();
	FCognitiveTools::RefreshDisplayDynamicObjectsCountInScene();
	FCognitiveTools::SearchForBlender();

	FString EngineIni = FPaths::Combine(*(FPaths::GameDir()), TEXT("Config/DefaultEngine.ini"));
	FString EditorIni = FPaths::Combine(*(FPaths::GameDir()), TEXT("Config/DefaultEditor.ini"));

	GConfig->GetString(TEXT("Analytics"), TEXT("ApiKey"), APIKey, EngineIni);
	GConfig->GetString(TEXT("Analytics"), TEXT("DeveloperKey"), FAnalyticsCognitiveVR::Get().DeveloperKey, EditorIni);
}

TSharedRef<ITableRow> FCognitiveTools::OnGenerateWorkspaceRow(TSharedPtr<FEditorSceneData> InItem, const TSharedRef<STableViewBase>& OwnerTable)
{
	return
		SNew(SComboRow< TSharedPtr<FEditorSceneData> >, OwnerTable)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.FillWidth(1)
			.Padding(2.0f)
			[
				SNew(STextBlock)
				.Text(FText::FromString(InItem->Name))
			]
			+ SHorizontalBox::Slot()
			.FillWidth(1)
			.Padding(2.0f)
			[
				SNew(STextBlock)
				.Text(FText::FromString(InItem->Id))
			]
			+ SHorizontalBox::Slot()
			.FillWidth(0.3)
			.Padding(2.0f)
			[
				SNew(STextBlock)
				.Text(FText::FromString(FString::FromInt(InItem->VersionNumber)))
			]
			+ SHorizontalBox::Slot()
			.FillWidth(0.3)
			.Padding(2.0f)
			[
				SNew(STextBlock)
				.Text(FText::FromString(FString::FromInt(InItem->VersionId)))
			]
			+ SHorizontalBox::Slot()
			.FillWidth(1)
			.Padding(2.0f)
			[
				SNew(SButton)
				.Text(FText::FromString("Open in Browser..."))
				.OnClicked(this,&FCognitiveTools::OpenSceneInBrowser,InItem->Id)
			]
		];
}

TSharedRef<ITableRow> FCognitiveTools::OnGenerateDynamicRow(TSharedPtr<FDynamicData> InItem, const TSharedRef<STableViewBase>& OwnerTable)
{
	return
		SNew(SComboRow< TSharedPtr<FDynamicData> >, OwnerTable)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.FillWidth(1)
			.Padding(2.0f)
			[
				SNew(STextBlock)
				.Text(FText::FromString(InItem->Name))
			]
			+ SHorizontalBox::Slot()
			.FillWidth(1)
			.Padding(2.0f)
			[
				SNew(STextBlock)
				.Text(FText::FromString(InItem->MeshName))
			]
			+ SHorizontalBox::Slot()
			.FillWidth(0.3)
			.Padding(2.0f)
			[
				SNew(STextBlock)
				.Text(FText::FromString(InItem->Id))
			]
		];
}

void FCognitiveTools::OnAPIKeyChanged(const FText& Text)
{
	APIKey = Text.ToString();
	//FAnalyticsCognitiveVR::GetCognitiveVRProvider()->APIKey = APIKey;
	//FAnalytics::Get().GetConfigValueFromIni(GEngineIni, "Analytics", "ApiKey", false);
}

FText FCognitiveTools::GetAPIKey() const
{
	return FText::FromString(APIKey);
}

FText FCognitiveTools::GetDeveloperKey() const
{
	return FText::FromString(FAnalyticsCognitiveVR::Get().DeveloperKey);
}

void FCognitiveTools::OnDeveloperKeyChanged(const FText& Text)
{
	FAnalyticsCognitiveVR::Get().DeveloperKey = Text.ToString();
}

FText FCognitiveTools::UploadSceneNameFiles() const
{
	auto currentscenedata = GetCurrentSceneData();
	if (!currentscenedata.IsValid())
	{
		UWorld* myworld = GWorld->GetWorld();

		FString currentSceneName = myworld->GetMapName();
		currentSceneName.RemoveFromStart(myworld->StreamingLevelsPrefix);

		return FText::FromString("Upload Files for " + currentSceneName);
	}
	FString outstring = "Upload Files for " + currentscenedata->Name;

	return FText::FromString(outstring);
}

FText FCognitiveTools::OpenSceneNameInBrowser() const
{
	auto currentscenedata = GetCurrentSceneData();
	if (!currentscenedata.IsValid())
	{
		UWorld* myworld = GWorld->GetWorld();

		FString currentSceneName = myworld->GetMapName();
		currentSceneName.RemoveFromStart(myworld->StreamingLevelsPrefix);

		return FText::FromString("Open" + currentSceneName + " in Browser...");
	}
	FString outstring = "Open " + currentscenedata->Name + " in Browser...";

	return FText::FromString(outstring);
}

FText FCognitiveTools::GetDynamicObjectUploadText() const
{
	auto data = GetCurrentSceneData();
	if (!data.IsValid())
	{
		return FText::FromString("No Scene Data found");
	}

	return FText::FromString("Upload "+FString::FromInt(SubDirectoryNames.Num())+" Dynamic Object Meshes to " + data->Name + " version " + FString::FromInt(data->VersionNumber));
}

FText FCognitiveTools::GetDynamicsFromManifest() const
{
	return FText::FromString("DYNAMICS");
}

FReply FCognitiveTools::RefreshDynamicSubDirectory()
{
	FindAllSubDirectoryNames();
	SubDirectoryListWidget->RefreshList();
	return FReply::Handled();
}

FReply FCognitiveTools::DebugRefreshCurrentScene()
{
	TSharedPtr<FEditorSceneData> scenedata = GetCurrentSceneData();

	if (scenedata.IsValid())
	{
		SceneVersionRequest(*scenedata);
	}

	return FReply::Handled();
}

FReply FCognitiveTools::OpenSceneInBrowser(FString sceneid)
{
	FString url = SceneExplorerOpen(sceneid);

	FPlatformProcess::LaunchURL(*url, nullptr, nullptr);

	return FReply::Handled();
}

FReply FCognitiveTools::OpenCurrentSceneInBrowser()
{
	TSharedPtr<FEditorSceneData> scenedata = GetCurrentSceneData();

	if (!scenedata.IsValid())
	{
		return FReply::Handled();
	}

	FString url = SceneExplorerOpen(scenedata->Id);

	return FReply::Handled();
}

FReply FCognitiveTools::RefreshSceneData()
{
	SceneData.Empty();

	TArray<FString>scenstrings;
	FString TestSyncFile = FPaths::Combine(*(FPaths::GameDir()), TEXT("Config/DefaultEngine.ini"));
	GConfig->GetArray(TEXT("/Script/CognitiveVR.CognitiveVRSceneSettings"), TEXT("SceneData"), scenstrings,TestSyncFile);

	for (int i = 0; i < scenstrings.Num(); i++)
	{
		TArray<FString> Array;
		scenstrings[i].ParseIntoArray(Array, TEXT(","), true);

		if (Array.Num() == 2) //scenename,sceneid
		{
			//old scene data. append versionnumber and versionid
			Array.Add("1");
			Array.Add("0");
		}

		if (Array.Num() != 4)
		{
			GLog->Log("FCognitiveTools::RefreshSceneData failed to parse " + scenstrings[i]);
			continue;
		}

		FEditorSceneData* tempscene = new FEditorSceneData(Array[0], Array[1], FCString::Atoi(*Array[2]), FCString::Atoi(*Array[3]));
		SceneData.Add(MakeShareable(tempscene));
	}
	
	GLog->Log("FCognitiveTools::RefreshSceneData found this many scenes: " + FString::FromInt(SceneData.Num()));
	//ConfigFileHasChanged = true;

	return FReply::Handled();
}

void FCognitiveTools::SceneVersionRequest(FEditorSceneData data)
{
	if (!HasDeveloperKey())
	{
		GLog->Log("FCognitiveTools::SceneVersionRequest no auth token. TODO get auth token and retry");
		//auto httprequest = RequestAuthTokenCallback();
		//httprequest->OnProcessRequestComplete().BindSP(this, &FCognitiveTools::OnSceneVersionGetAuthToken);
		return;
	}

	TSharedRef<IHttpRequest> HttpRequest = FHttpModule::Get().CreateRequest();

	HttpRequest->SetURL(GetSceneVersion(data.Id));

	GLog->Log("FCognitiveTools::SceneVersionRequest send scene version request");

	HttpRequest->SetHeader("X-HTTP-Method-Override", TEXT("GET"));
	//HttpRequest->SetHeader("Authorization", TEXT("Data " + FAnalyticsCognitiveVR::Get().EditorAuthToken));
	FString AuthValue = "APIKEY:DEVELOPER " + FAnalyticsCognitiveVR::Get().DeveloperKey;
	HttpRequest->SetHeader("Authorization", AuthValue);

	HttpRequest->OnProcessRequestComplete().BindSP(this, &FCognitiveTools::SceneVersionResponse);
	HttpRequest->ProcessRequest();
}

void FCognitiveTools::SceneVersionResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	int32 responseCode = Response->GetResponseCode();

	//GLog->Log("FCognitiveTools::SceneVersionResponse response: " + Response->GetContentAsString());

	if (responseCode >= 500)
	{
		//internal server error
		GLog->Log("FCognitiveTools::SceneVersionResponse 500-ish internal server error");
		return;
	}
	if (responseCode >= 400)
	{
		if (responseCode == 401)
		{
			//not authorized
			GLog->Log("FCognitiveTools::SceneVersionResponse not authorized!");
			//DEBUG_RequestAuthToken();
			//auto httprequest = RequestAuthTokenCallback();
			//if (httprequest)
			//{
				//httprequest->OnProcessRequestComplete().BindSP(this, &FCognitiveTools::OnSceneVersionGetAuthToken);
			//}
			return;
		}
		else
		{
			//maybe no scene?
			GLog->Log("FCognitiveTools::SceneVersionResponse some error. Maybe no scene?");
			return;
		}
	}

	//parse response content to json

	TSharedPtr<FJsonObject> JsonSceneSettings;

	TSharedRef<TJsonReader<>>Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());
	if (FJsonSerializer::Deserialize(Reader, JsonSceneSettings))
	{
		//get the latest version of the scene
		int32 versionNumber = 0;
		int32 versionId = 0;
		TArray<TSharedPtr<FJsonValue>> versions = JsonSceneSettings->GetArrayField("versions");
		for (int i = 0; i < versions.Num(); i++) {

			int32 tempversion = versions[i]->AsObject()->GetNumberField("versionnumber");
			if (tempversion > versionNumber)
			{
				versionNumber = tempversion;
				versionId = versions[i]->AsObject()->GetNumberField("id");
			}
		}
		if (versionNumber + versionId == 0)
		{
			GLog->Log("FCognitiveTools::SceneVersionResponse couldn't find a latest version in SceneVersion data");
			return;
		}

		//check that there is scene data in ini
		TSharedPtr<FEditorSceneData> currentSceneData = GetCurrentSceneData();
		if (!currentSceneData.IsValid())
		{
			GLog->Log("FCognitiveTools::SceneVersionResponse can't find current scene data in ini files");
			return;
		}

		//get array of scene data
		TArray<FString> iniscenedata;

		FString TestSyncFile = FPaths::Combine(*(FPaths::GameDir()), TEXT("Config/DefaultEngine.ini"));
		GConfig->GetArray(TEXT("/Script/CognitiveVR.CognitiveVRSceneSettings"), TEXT("SceneData"), iniscenedata, TestSyncFile);

		//GLog->Log("found this many scene datas in ini " + FString::FromInt(iniscenedata.Num()));
		//GLog->Log("looking for scene " + currentSceneData->Name);

		//update current scene
		for (int i = 0; i < iniscenedata.Num(); i++)
		{
			//GLog->Log("looking at data " + iniscenedata[i]);

			TArray<FString> entryarray;
			iniscenedata[i].ParseIntoArray(entryarray, TEXT(","), true);

			if (entryarray[0] == currentSceneData->Name)
			{
				iniscenedata[i] = entryarray[0] + "," + entryarray[1] + "," + FString::FromInt(versionNumber) + "," + FString::FromInt(versionId);
				//GLog->Log("FCognitiveToolsCustomization::SceneVersionResponse overwriting scene data to append versionnumber and versionid");
				//GLog->Log(iniscenedata[i]);
				break;
			}
			else
			{
				//GLog->Log("found scene " + entryarray[0]);
			}
		}

		GLog->Log("FCognitiveTools::SceneVersionResponse successful. Write scene data to config file");

		//set array to config
		GConfig->RemoveKey(TEXT("/Script/CognitiveVR.CognitiveVRSceneSettings"), TEXT("SceneData"), TestSyncFile);
		//GConfig->Remove(
		GConfig->SetArray(TEXT("/Script/CognitiveVR.CognitiveVRSceneSettings"), TEXT("SceneData"), iniscenedata, TestSyncFile);
		GConfig->Flush(false, GEngineIni);
		ConfigFileHasChanged = true;
	}
	else
	{
		GLog->Log("FCognitiveToolsCustomization::SceneVersionResponse failed to parse json response");
	}
}

/*void FCognitiveTools::OnSceneVersionGetAuthToken(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	if (bWasSuccessful)
	{
		auto scene = GetCurrentSceneData();
		if (scene.IsValid())
		{
			SceneVersionRequest(*scene);
		}
	}
}*/

TArray<TSharedPtr<FEditorSceneData>> FCognitiveTools::GetSceneData() const
{
	return SceneData;
}

ECheckBoxState FCognitiveTools::HasFoundBlenderCheckbox() const
{
	return (HasFoundBlender())
		? ECheckBoxState::Checked
		: ECheckBoxState::Unchecked;
}

FReply FCognitiveTools::SaveAPIDeveloperKeysToFile()
{
	FString EngineIni = FPaths::Combine(*(FPaths::GameDir()), TEXT("Config/DefaultEngine.ini"));
	FString EditorIni = FPaths::Combine(*(FPaths::GameDir()), TEXT("Config/DefaultEditor.ini"));
	//GLog->Log("FCognitiveTools::SaveAPIDeveloperKeysToFile save: " + CustomerId);

	GConfig->SetString(TEXT("Analytics"), TEXT("ProviderModuleName"), TEXT("CognitiveVR"), EngineIni);
	GConfig->SetString(TEXT("Analytics"), TEXT("ApiKey"), *APIKey, EngineIni);

	GConfig->SetString(TEXT("Analytics"), TEXT("DeveloperKey"), *FAnalyticsCognitiveVR::Get().DeveloperKey, EditorIni);

	GConfig->Flush(false, GEngineIni);

	ConfigFileHasChanged = true;

	return FReply::Handled();
}

FReply FCognitiveTools::ReexportDynamicMeshesCmd()
{
	ReexportDynamicMeshes(ExportDynamicsDirectory);
	return FReply::Handled();
}

FReply FCognitiveTools::ExportDynamicTextures()
{
	ConvertDynamicTextures();
	return FReply::Handled();
}

TSharedPtr<FEditorSceneData> FCognitiveTools::GetCurrentSceneData() const
{
	UWorld* myworld = GWorld->GetWorld();

	FString currentSceneName = myworld->GetMapName();
	currentSceneName.RemoveFromStart(myworld->StreamingLevelsPrefix);
	return GetSceneData(currentSceneName);
}

FString lastSceneName;
TSharedPtr<FEditorSceneData> FCognitiveTools::GetSceneData(FString scenename) const
{
	for (int i = 0; i < SceneData.Num(); i++)
	{
		if (!SceneData[i].IsValid()) { continue; }
		if (SceneData[i]->Name == scenename)
		{
			return SceneData[i];
		}
	}
	if (lastSceneName != scenename)
	{
		GLog->Log("FCognitiveToolsCustomization::GetSceneData couldn't find SceneData for scene " + scenename);
		lastSceneName = scenename;
	}
	return NULL;
}

void FCognitiveTools::SaveSceneData(FString sceneName, FString sceneKey)
{
	FString keyValue = sceneName + "," + sceneKey;

	TArray<FString> scenePairs = TArray<FString>();

	FString TestSyncFile = FPaths::Combine(*(FPaths::GameDir()), TEXT("Config/DefaultEngine.ini"));
	GConfig->GetArray(TEXT("/Script/CognitiveVR.CognitiveVRSceneSettings"), TEXT("SceneData"), scenePairs, TestSyncFile);

	bool didSetKey = false;
	for (int32 i = 0; i < scenePairs.Num(); i++)
	{
		FString name;
		FString key;
		scenePairs[i].Split(TEXT(","), &name, &key);
		if (*name == sceneName)
		{
			scenePairs[i] = keyValue;
			didSetKey = true;
			GLog->Log("FCognitiveToolsCustomization::SaveSceneData - found and replace key for scene " + name + " new value " + keyValue);
			break;
		}
	}
	if (!didSetKey)
	{
		scenePairs.Add(keyValue);
		GLog->Log("FCognitiveToolsCustomization::SaveSceneData - added new scene value and key for " + sceneName);
	}

	//remove scene names that don't have keys!
	for (int32 i = scenePairs.Num()-1; i >= 0; i--)
	{
		FString name;
		FString key;
		if (!scenePairs[i].Split(TEXT(","), &name, &key))
		{
			scenePairs.RemoveAt(i);
		}
	}

	GConfig->SetArray(TEXT("/Script/CognitiveVR.CognitiveVRSceneSettings"), TEXT("SceneData"), scenePairs, TestSyncFile);

	GConfig->Flush(false, GEngineIni);
}

#undef LOCTEXT_NAMESPACE